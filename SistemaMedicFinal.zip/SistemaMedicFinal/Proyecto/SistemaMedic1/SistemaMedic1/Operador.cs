﻿using System;

namespace SistemaMedic
{
    public class Operador : Persona
    {
        public int IdOperador
        {
            get { return Id; }
            set { Id = value; }
        }

        public int NumeroVentanilla { get; set; }

        public Operador(string nombre, string dpi, int numeroVentanilla)
            : base(nombre, dpi, "")
        {
            NumeroVentanilla = numeroVentanilla;
        }

        public Operador() { }

        public override string ObtenerInfo()
        {
            return $"Operador: {Nombre} | Ventanilla: {NumeroVentanilla}";
        }
    }
}