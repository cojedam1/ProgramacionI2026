﻿using SistemaMedic;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace SistemaMedic
{
    public partial class FrmLogin : Form
    {
        private OperadorRepositorio _operadorRepo;
        public Operador OperadorSeleccionado { get; private set; }

        private Label lblTitulo, lblInstruccion;
        private ListBox lstOperadores;
        private Button btnIngresar, btnSalir;

        public FrmLogin()
        {
            _operadorRepo = new OperadorRepositorio();
            InicializarComponentes();
            CargarOperadores();
        }

        private void InicializarComponentes()
        {
            lblTitulo = new Label
            {
                Text = "SistemaMedic",
                Font = new Font("Segoe UI", 24F, FontStyle.Bold),
                Location = new Point(0, 30),
                Size = new Size(500, 45),
                TextAlign = ContentAlignment.MiddleCenter,
                ForeColor = Color.SteelBlue
            };

            lblInstruccion = new Label
            {
                Text = "Seleccione su usuario para ingresar",
                Font = new Font("Segoe UI", 11F),
                Location = new Point(0, 85),
                Size = new Size(500, 25),
                TextAlign = ContentAlignment.MiddleCenter,
                ForeColor = Color.DimGray
            };

            lstOperadores = new ListBox
            {
                Location = new Point(80, 130),
                Size = new Size(340, 180),
                Font = new Font("Segoe UI", 11F),
                BorderStyle = BorderStyle.FixedSingle
            };

            btnIngresar = new Button
            {
                Text = "Ingresar",
                Location = new Point(80, 330),
                Size = new Size(220, 45),
                BackColor = Color.SeaGreen,
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 11F, FontStyle.Bold)
            };

            btnSalir = new Button
            {
                Text = "Salir",
                Location = new Point(310, 330),
                Size = new Size(110, 45)
            };

            btnIngresar.Click += btnIngresar_Click;
            btnSalir.Click += (s, e) => Application.Exit();
            lstOperadores.DoubleClick += btnIngresar_Click;

            ClientSize = new Size(500, 400);
            Text = "SistemaMedic - Inicio de sesión";
            StartPosition = FormStartPosition.CenterScreen;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;

            Controls.AddRange(new Control[] { lblTitulo, lblInstruccion, lstOperadores, btnIngresar, btnSalir });
        }

        private void CargarOperadores()
        {
            List<Operador> operadores = _operadorRepo.ObtenerTodos();
            lstOperadores.Items.Clear();

            for (int i = 0; i < operadores.Count; i++)
            {
                var op = operadores[i];
                string item = $"  {op.Nombre}  -  Ventanilla {op.NumeroVentanilla}";
                lstOperadores.Items.Add(item);
            }

            lstOperadores.Tag = operadores;
        }

        private void btnIngresar_Click(object sender, EventArgs e)
        {
            if (lstOperadores.SelectedIndex < 0)
            {
                MessageBox.Show("Seleccione un operador de la lista.", "Validación",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var operadores = (List<Operador>)lstOperadores.Tag;
            OperadorSeleccionado = operadores[lstOperadores.SelectedIndex];

            DialogResult = DialogResult.OK;
            Close();
        }
    }
}