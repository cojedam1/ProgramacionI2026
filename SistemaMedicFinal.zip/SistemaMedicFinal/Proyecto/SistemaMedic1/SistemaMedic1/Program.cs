using System;
using System.Windows.Forms;

namespace SistemaMedic
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            ApplicationConfiguration.Initialize();

            // Mostrar pantalla de login primero
            FrmLogin login = new FrmLogin();
            if (login.ShowDialog() != DialogResult.OK)
            {
                return; // El usuario cerró o no seleccionó operador
            }

            Operador operadorActual = login.OperadorSeleccionado;

            // Crear el gestor compartido
            GestorTurno gestor = new GestorTurno();

            // Crear los dos formularios con el operador seleccionado
            FrmRegistro frmRegistro = new FrmRegistro(gestor);
            FrmOperador frmOperador = new FrmOperador(gestor, operadorActual);

            // Posicionar las ventanas lado a lado
            frmRegistro.StartPosition = FormStartPosition.Manual;
            frmOperador.StartPosition = FormStartPosition.Manual;
            frmRegistro.Location = new System.Drawing.Point(100, 100);
            frmOperador.Location = new System.Drawing.Point(620, 100);

            // Mostrar ambos
            frmOperador.Show();
            Application.Run(frmRegistro);
        }
    }
}