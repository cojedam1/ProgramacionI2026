﻿namespace SistemaMedic
{
    public class Servicio
    {
        public int IdServicio { get; set; }
        public string NombreServicio { get; set; }
        public string Descripcion { get; set; }

        public override string ToString()
        {
            return NombreServicio;
        }
    }
}