﻿using System;

namespace SistemaMedic
{
    public abstract class Turno
    {
        public int IdTurno { get; set; }
        public int NumeroTurno { get; set; }
        public DateTime HoraRegistro { get; set; }
        public DateTime? HoraLlamado { get; set; }
        public string TipoTurno { get; set; }
        public string Estado { get; set; }
        public int IdServicio { get; set; }
        public int IdPaciente { get; set; }
        public int? IdOperador { get; set; }

        public Paciente Paciente { get; set; }
        public string NombreServicio { get; set; }

        public Turno(int numeroTurno, int idServicio, int idPaciente)
        {
            NumeroTurno = numeroTurno;
            HoraRegistro = DateTime.Now;
            Estado = "Espera";
            IdServicio = idServicio;
            IdPaciente = idPaciente;
        }

        public Turno() { }

        public abstract string MostrarTurno();
        public abstract int ObtenerPrioridad();

        public override string ToString()
        {
            return $"Turno #{NumeroTurno} - {TipoTurno} - {Estado}";
        }
    }
}