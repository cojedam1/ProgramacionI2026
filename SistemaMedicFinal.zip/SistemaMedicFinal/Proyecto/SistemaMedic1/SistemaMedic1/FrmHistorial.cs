﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace SistemaMedic
{
    public partial class FrmHistorial : Form
    {
        private TurnoRepositorio _turnoRepo;
        private Label lblTitulo;
        private DataGridView dgvHistorial;
        private Button btnExportar, btnCerrar;
        private Label lblTotal;

        public FrmHistorial()
        {
            _turnoRepo = new TurnoRepositorio();
            InicializarComponentes();
            CargarHistorial();
        }

        private void InicializarComponentes()
        {
            lblTitulo = new Label { Text = "SistemaMedic - Historial del Día", Font = new Font("Segoe UI", 14F, FontStyle.Bold), Location = new Point(20, 20), Size = new Size(660, 30), TextAlign = ContentAlignment.MiddleCenter };

            dgvHistorial = new DataGridView
            {
                Location = new Point(20, 65),
                Size = new Size(660, 350),
                ReadOnly = true,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                AllowUserToAddRows = false,
                BackgroundColor = Color.White
            };

            lblTotal = new Label { Text = "Total atendidos: 0", Location = new Point(20, 425), Size = new Size(300, 23), Font = new Font("Segoe UI", 10F, FontStyle.Bold) };

            btnExportar = new Button { Text = "Exportar a .txt", Location = new Point(460, 420), Size = new Size(110, 35), BackColor = Color.SeaGreen, ForeColor = Color.White };
            btnCerrar = new Button { Text = "Cerrar", Location = new Point(580, 420), Size = new Size(100, 35) };

            btnExportar.Click += btnExportar_Click;
            btnCerrar.Click += (s, e) => Close();

            ClientSize = new Size(700, 470);
            Text = "SistemaMedic - Historial del Día";
            StartPosition = FormStartPosition.CenterScreen;

            Controls.AddRange(new Control[] { lblTitulo, dgvHistorial, lblTotal, btnExportar, btnCerrar });
        }

        private void CargarHistorial()
        {
            var historial = _turnoRepo.ObtenerHistorialHoy();

            dgvHistorial.Rows.Clear();
            dgvHistorial.Columns.Clear();

            dgvHistorial.Columns.Add("NumeroTurno", "# Turno");
            dgvHistorial.Columns.Add("NombrePaciente", "Paciente");
            dgvHistorial.Columns.Add("NombreServicio", "Servicio");
            dgvHistorial.Columns.Add("TipoTurno", "Tipo");
            dgvHistorial.Columns.Add("HoraRegistro", "Hora Registro");
            dgvHistorial.Columns.Add("HoraLlamado", "Hora Llamado");
            dgvHistorial.Columns.Add("Estado", "Estado");

            // For loop para cargar historial
            for (int i = 0; i < historial.Count; i++)
            {
                var t = historial[i];
                dgvHistorial.Rows.Add(
                    $"#{t.NumeroTurno:D3}",
                    t.NombreServicio,
                    t.TipoTurno,
                    t.HoraRegistro.ToString("HH:mm"),
                    t.HoraLlamado.HasValue ? t.HoraLlamado.Value.ToString("HH:mm") : "---",
                    t.Estado
                );
            }

            lblTotal.Text = $"Total atendidos: {historial.Count}";
        }

        private void btnExportar_Click(object sender, EventArgs e)
        {
            var exportador = new ExportadorLog();
            string archivo = exportador.ExportarHistorial(_turnoRepo.ObtenerHistorialHoy());
            MessageBox.Show($"Historial exportado a:\n{archivo}", "Exportado", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}