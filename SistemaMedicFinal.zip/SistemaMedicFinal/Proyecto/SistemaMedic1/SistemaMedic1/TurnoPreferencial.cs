﻿using System;

namespace SistemaMedic
{
    public class TurnoPreferencial : Turno
    {
        public TurnoPreferencial(int numeroTurno, int idServicio, int idPaciente)
            : base(numeroTurno, idServicio, idPaciente)
        {
            TipoTurno = "Preferencial";
        }

        // Constructor vacío para Dapper
        public TurnoPreferencial() { }

        public override string MostrarTurno()
        {
            return $"*** TURNO PREFERENCIAL #{NumeroTurno:D3} *** - {NombreServicio}";
        }

        public override int ObtenerPrioridad()
        {
            return 1;
        }
    }
}