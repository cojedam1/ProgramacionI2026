﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace SistemaMedic
{
    public partial class FrmRegistro : Form
    {
        private GestorTurno _gestor;
        private PacienteRepositorio _pacienteRepo;
        private ServicioRepositorio _servicioRepo;

        private Label lblTitulo, lblNombre, lblDPI, lblTelefono, lblFecha, lblServicio, lblPreferencial, lblMensaje;
        private TextBox txtNombre, txtDPI, txtTelefono;
        private DateTimePicker dtpFechaNacimiento;
        private ComboBox cmbServicio;
        private CheckBox chkPreferencial;
        private Button btnRegistrar, btnLimpiar;

        public FrmRegistro(GestorTurno gestor)
        {
            _gestor = gestor;
            _pacienteRepo = new PacienteRepositorio();
            _servicioRepo = new ServicioRepositorio();
            InicializarComponentes();
            CargarServicios();
        }

        private void InicializarComponentes()
        {
            lblTitulo = new Label { Text = "SistemaMedic - Registro de Turno", Font = new Font("Segoe UI", 14F, FontStyle.Bold), Location = new Point(50, 20), Size = new Size(400, 30), TextAlign = ContentAlignment.MiddleCenter };
            lblNombre = new Label { Text = "Nombre completo:", Location = new Point(50, 70), Size = new Size(130, 23) };
            txtNombre = new TextBox { Location = new Point(190, 67), Size = new Size(250, 23) };
            lblDPI = new Label { Text = "DPI:", Location = new Point(50, 110), Size = new Size(130, 23) };
            txtDPI = new TextBox { Location = new Point(190, 107), Size = new Size(250, 23) };
            lblTelefono = new Label { Text = "Teléfono:", Location = new Point(50, 150), Size = new Size(130, 23) };
            txtTelefono = new TextBox { Location = new Point(190, 147), Size = new Size(250, 23) };
            lblFecha = new Label { Text = "Fecha de nacimiento:", Location = new Point(50, 190), Size = new Size(160, 23) };
            dtpFechaNacimiento = new DateTimePicker { Location = new Point(220, 187), Size = new Size(220, 23), Format = DateTimePickerFormat.Short, Value = DateTime.Now.AddYears(-30) };
            lblServicio = new Label { Text = "Servicio:", Location = new Point(50, 230), Size = new Size(130, 23) };
            cmbServicio = new ComboBox { Location = new Point(190, 227), Size = new Size(250, 23), DropDownStyle = ComboBoxStyle.DropDownList };

            chkPreferencial = new CheckBox
            {
                Text = "Atención preferencial (embarazo, discapacidad, etc.)",
                Location = new Point(50, 265),
                Size = new Size(390, 23),
                Font = new Font("Segoe UI", 9F)
            };

            lblPreferencial = new Label { Text = "", Location = new Point(50, 295), Size = new Size(390, 23), ForeColor = Color.DarkGreen, Font = new Font("Segoe UI", 9F, FontStyle.Bold), TextAlign = ContentAlignment.MiddleCenter };
            btnRegistrar = new Button { Text = "Registrar Turno", Location = new Point(190, 325), Size = new Size(120, 35), BackColor = Color.SteelBlue, ForeColor = Color.White };
            btnLimpiar = new Button { Text = "Limpiar", Location = new Point(320, 325), Size = new Size(120, 35) };
            lblMensaje = new Label { Text = "", Location = new Point(50, 375), Size = new Size(400, 30), TextAlign = ContentAlignment.MiddleCenter, Font = new Font("Segoe UI", 11F, FontStyle.Bold), ForeColor = Color.DarkGreen };

            btnRegistrar.Click += btnRegistrar_Click;
            btnLimpiar.Click += btnLimpiar_Click;

            ClientSize = new Size(500, 430);
            Text = "SistemaMedic - Registro de Turno";
            StartPosition = FormStartPosition.CenterScreen;

            Controls.AddRange(new Control[] { lblTitulo, lblNombre, txtNombre, lblDPI, txtDPI, lblTelefono, txtTelefono, lblFecha, dtpFechaNacimiento, lblServicio, cmbServicio, chkPreferencial, lblPreferencial, btnRegistrar, btnLimpiar, lblMensaje });
        }

        private void CargarServicios()
        {
            var servicios = _servicioRepo.ObtenerTodos();
            cmbServicio.DataSource = servicios;
            cmbServicio.DisplayMember = "NombreServicio";
            cmbServicio.ValueMember = "IdServicio";
        }

        private void btnRegistrar_Click(object sender, EventArgs e)
        {
            if (!ValidarCampos()) return;
            try
            {
                string dpi = txtDPI.Text.Trim();
                Paciente paciente;

                if (_pacienteRepo.ExisteDPI(dpi))
                {
                    paciente = _pacienteRepo.ObtenerPorDPI(dpi);
                    // Si marcaron preferencial, actualizar
                    if (chkPreferencial.Checked) paciente.EsPreferencial = true;
                }
                else
                {
                    paciente = new Paciente(
                        txtNombre.Text.Trim(),
                        dpi,
                        txtTelefono.Text.Trim(),
                        dtpFechaNacimiento.Value,
                        chkPreferencial.Checked
                    );
                    paciente.Id = _pacienteRepo.Insertar(paciente);
                }

                int idServicio = (int)cmbServicio.SelectedValue;
                Turno turno = _gestor.RegistrarTurno(paciente, idServicio);

                string razon = "";
                if (paciente.EsPreferencial)
                {
                    if (paciente.ObtenerEdad() >= 60)
                        razon = "(Adulto mayor)";
                    else
                        razon = "(Atención especial)";
                }

                lblPreferencial.Text = paciente.EsPreferencial ? $"★ Turno Preferencial {razon}" : "";
                lblMensaje.Text = $"✓ Turno #{turno.NumeroTurno:D3} registrado - {turno.TipoTurno}";
                lblMensaje.ForeColor = Color.DarkGreen;
                MessageBox.Show($"Turno #{turno.NumeroTurno:D3} registrado correctamente.\nTipo: {turno.TipoTurno}\nServicio: {turno.NombreServicio}",
                    "Turno Registrado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LimpiarFormulario();
            }
            catch (Exception ex)
            {
                lblMensaje.Text = "Error al registrar turno.";
                lblMensaje.ForeColor = Color.Red;
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private bool ValidarCampos()
        {
            if (string.IsNullOrWhiteSpace(txtNombre.Text)) { MessageBox.Show("Ingrese el nombre.", "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning); return false; }
            if (string.IsNullOrWhiteSpace(txtDPI.Text)) { MessageBox.Show("Ingrese el DPI.", "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning); return false; }
            if (cmbServicio.SelectedValue == null) { MessageBox.Show("Seleccione un servicio.", "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning); return false; }
            return true;
        }

        private void btnLimpiar_Click(object sender, EventArgs e) => LimpiarFormulario();

        private void LimpiarFormulario()
        {
            txtNombre.Clear(); txtDPI.Clear(); txtTelefono.Clear();
            dtpFechaNacimiento.Value = DateTime.Now.AddYears(-30);
            chkPreferencial.Checked = false;
            lblMensaje.Text = ""; lblPreferencial.Text = "";
            txtNombre.Focus();
        }
    }
}