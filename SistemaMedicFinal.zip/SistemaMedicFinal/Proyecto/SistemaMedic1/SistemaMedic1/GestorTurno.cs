﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace SistemaMedic
{
    public class GestorTurno
    {
        // Colecciones requeridas por el proyecto
        private Queue<Turno> _colaTurnos;
        private List<Paciente> _pacientesHoy;
        private Turno _turnoActual;

        // Repositorios
        private TurnoRepositorio _turnoRepo;
        private PacienteRepositorio _pacienteRepo;
        private ServicioRepositorio _servicioRepo;

        // Evento para notificar a la pantalla de sala
        public event Action<Turno> TurnoLlamado;

        public GestorTurno()
        {
            _colaTurnos = new Queue<Turno>();
            _pacientesHoy = new List<Paciente>();
            _turnoRepo = new TurnoRepositorio();
            _pacienteRepo = new PacienteRepositorio();
            _servicioRepo = new ServicioRepositorio();

            CargarTurnosPendientes();
        }

        // Carga turnos pendientes desde la BD al iniciar
        private void CargarTurnosPendientes()
        {
            var pendientes = _turnoRepo.ObtenerPendientes();
            foreach (var turno in pendientes)
            {
                _colaTurnos.Enqueue(turno);
            }
        }

        // Registrar nuevo turno
        public Turno RegistrarTurno(Paciente paciente, int idServicio)
        {
            int ultimoNumero = _turnoRepo.ObtenerUltimoNumero();
            int nuevoNumero = ultimoNumero + 1;

            Turno turno;

            // IF-ELSE para determinar tipo de turno
            if (paciente.EsPreferencial)
            {
                turno = new TurnoPreferencial(nuevoNumero, idServicio, paciente.Id);
            }
            else
            {
                turno = new TurnoNormal(nuevoNumero, idServicio, paciente.Id);
            }

            // Obtener nombre del servicio
            var servicio = _servicioRepo.ObtenerPorId(idServicio);
            turno.NombreServicio = servicio?.NombreServicio ?? "";
            turno.Paciente = paciente;

            // Guardar en BD
            turno.IdTurno = _turnoRepo.Insertar(turno);

            // Agregar a la cola según prioridad
            AgregarConPrioridad(turno);

            // Agregar paciente a la lista del día
            if (!_pacientesHoy.Any(p => p.Id == paciente.Id))
            {
                _pacientesHoy.Add(paciente);
            }

            return turno;
        }

        // Agrega turno respetando prioridad preferencial
        private void AgregarConPrioridad(Turno nuevoTurno)
        {
            // Switch para manejar prioridades
            switch (nuevoTurno.ObtenerPrioridad())
            {
                case 1: // Preferencial - va al frente
                    var listaTemp = _colaTurnos.ToList();
                    listaTemp.Insert(0, nuevoTurno);
                    _colaTurnos = new Queue<Turno>(listaTemp);
                    break;
                case 2: // Normal - va al final
                default:
                    _colaTurnos.Enqueue(nuevoTurno);
                    break;
            }
        }

        // Llamar siguiente turno
        public Turno LlamarSiguiente(int idOperador)
        {
            if (_colaTurnos.Count == 0)
                return null;

            _turnoActual = _colaTurnos.Dequeue();
            _turnoRepo.ActualizarEstado(_turnoActual.IdTurno, "Atendido", idOperador);
            _turnoActual.Estado = "Atendido";

            // Notificar a la pantalla de sala
            TurnoLlamado?.Invoke(_turnoActual);

            return _turnoActual;
        }

        // Getters
        public int CantidadEnEspera() => _colaTurnos.Count;
        public Turno ObtenerTurnoActual() => _turnoActual;
        public List<Paciente> ObtenerPacientesHoy() => _pacientesHoy;
        public Queue<Turno> ObtenerCola() => _colaTurnos;
    }
}