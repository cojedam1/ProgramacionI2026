﻿using System;

namespace SistemaMedic
{
    public class Paciente : Persona
    {
        public DateTime FechaNacimiento { get; set; }
        public bool EsPreferencial { get; set; }

        // Constructor con edad automática
        public Paciente(string nombre, string dpi, string telefono, DateTime fechaNacimiento)
            : base(nombre, dpi, telefono)
        {
            FechaNacimiento = fechaNacimiento;
            EsPreferencial = CalcularPreferencialPorEdad();
        }

        // Constructor con preferencial manual (para embarazadas, discapacidad, etc)
        public Paciente(string nombre, string dpi, string telefono, DateTime fechaNacimiento, bool esPreferencialManual)
            : base(nombre, dpi, telefono)
        {
            FechaNacimiento = fechaNacimiento;
            EsPreferencial = CalcularPreferencialPorEdad() || esPreferencialManual;
        }

        public Paciente() { }

        private bool CalcularPreferencialPorEdad()
        {
            return ObtenerEdad() >= 60;
        }

        public int ObtenerEdad()
        {
            int edad = DateTime.Now.Year - FechaNacimiento.Year;
            if (DateTime.Now.Month < FechaNacimiento.Month ||
               (DateTime.Now.Month == FechaNacimiento.Month && DateTime.Now.Day < FechaNacimiento.Day))
                edad--;
            return edad;
        }

        public override string ObtenerInfo()
        {
            string tipo = EsPreferencial ? "Preferencial" : "Normal";
            return $"Paciente: {Nombre} | DPI: {DPI} | Edad: {ObtenerEdad()} | Tipo: {tipo}";
        }
    }
}