﻿using Dapper;
using System;
using System.Collections.Generic;
using System.Linq;

namespace SistemaMedic
{
    public class TurnoRepositorio
    {
        public int Insertar(Turno turno)
        {
            using (var conexion = ConexionBD.ObtenerConexion())
            {
                string sql = @"INSERT INTO Turno (NumeroTurno, HoraRegistro, TipoTurno, Estado, IdServicio, IdPaciente)
                               VALUES (@NumeroTurno, @HoraRegistro, @TipoTurno, @Estado, @IdServicio, @IdPaciente);
                               SELECT CAST(SCOPE_IDENTITY() AS INT)";
                return conexion.ExecuteScalar<int>(sql, new
                {
                    turno.NumeroTurno,
                    turno.HoraRegistro,
                    turno.TipoTurno,
                    turno.Estado,
                    turno.IdServicio,
                    turno.IdPaciente
                });
            }
        }

        public List<Turno> ObtenerPendientes()
        {
            using (var conexion = ConexionBD.ObtenerConexion())
            {
                string sql = @"SELECT t.IdTurno, t.NumeroTurno, t.HoraRegistro, t.TipoTurno, 
                                      t.Estado, t.IdServicio, t.IdPaciente, t.IdOperador,
                                      p.Nombre AS NombrePaciente, p.EsPreferencial,
                                      s.NombreServicio
                               FROM Turno t
                               INNER JOIN Paciente p ON t.IdPaciente = p.IdPaciente
                               INNER JOIN Servicio s ON t.IdServicio = s.IdServicio
                               WHERE t.Estado = 'Espera'
                               ORDER BY t.TipoTurno DESC, t.HoraRegistro ASC";
                return conexion.Query<TurnoNormal>(sql).Cast<Turno>().ToList();
            }
        }

        public void ActualizarEstado(int idTurno, string estado, int? idOperador)
        {
            using (var conexion = ConexionBD.ObtenerConexion())
            {
                string sql = @"UPDATE Turno 
                               SET Estado = @Estado, 
                                   HoraLlamado = @HoraLlamado,
                                   IdOperador = @IdOperador
                               WHERE IdTurno = @IdTurno";
                conexion.Execute(sql, new
                {
                    Estado = estado,
                    HoraLlamado = DateTime.Now,
                    IdOperador = idOperador,
                    IdTurno = idTurno
                });
            }
        }

        public int ObtenerUltimoNumero()
        {
            using (var conexion = ConexionBD.ObtenerConexion())
            {
                string sql = @"SELECT ISNULL(MAX(NumeroTurno), 0) FROM Turno";
                return conexion.ExecuteScalar<int>(sql);
            }
        }

        public List<Turno> ObtenerHistorialHoy()
        {
            using (var conexion = ConexionBD.ObtenerConexion())
            {
                string sql = @"SELECT t.IdTurno, t.NumeroTurno, t.HoraRegistro, t.HoraLlamado,
                                      t.TipoTurno, t.Estado, p.Nombre AS NombrePaciente,
                                      s.NombreServicio
                               FROM Turno t
                               INNER JOIN Paciente p ON t.IdPaciente = p.IdPaciente
                               INNER JOIN Servicio s ON t.IdServicio = s.IdServicio
                               ORDER BY t.HoraRegistro ASC";
                return conexion.Query<TurnoNormal>(sql).Cast<Turno>().ToList();
            }
        }
    }
}