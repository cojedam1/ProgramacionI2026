﻿using Dapper;
using System.Collections.Generic;
using System.Linq;

namespace SistemaMedic
{
    public class OperadorRepositorio
    {
        public List<Operador> ObtenerTodos()
        {
            using (var conexion = ConexionBD.ObtenerConexion())
            {
                string sql = "SELECT IdOperador AS Id, Nombre, DPI, NumeroVentanilla FROM Operador";
                return conexion.Query<Operador>(sql).ToList();
            }
        }

        public Operador ObtenerPorId(int idOperador)
        {
            using (var conexion = ConexionBD.ObtenerConexion())
            {
                string sql = "SELECT IdOperador AS Id, Nombre, DPI, NumeroVentanilla FROM Operador WHERE IdOperador = @IdOperador";
                return conexion.QueryFirstOrDefault<Operador>(sql, new { IdOperador = idOperador });
            }
        }

        public Operador ObtenerPorVentanilla(int numeroVentanilla)
        {
            using (var conexion = ConexionBD.ObtenerConexion())
            {
                string sql = "SELECT IdOperador AS Id, Nombre, DPI, NumeroVentanilla FROM Operador WHERE NumeroVentanilla = @NumeroVentanilla";
                return conexion.QueryFirstOrDefault<Operador>(sql, new { NumeroVentanilla = numeroVentanilla });
            }
        }
    }
}