﻿using Microsoft.Data.SqlClient;
using System.Data;

namespace SistemaMedic
{
    public class ConexionBD
    {
        private static readonly string _connectionString =
            "Server=localhost\\SQLEXPRESS;Database=SistemaMedic;Trusted_Connection=True;TrustServerCertificate=True;";

        public static IDbConnection ObtenerConexion()
        {
            return new SqlConnection(_connectionString);
        }
    }
}