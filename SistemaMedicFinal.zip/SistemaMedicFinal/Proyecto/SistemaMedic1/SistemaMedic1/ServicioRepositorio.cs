﻿using Dapper;
using System.Collections.Generic;
using System.Linq;

namespace SistemaMedic
{
    public class ServicioRepositorio
    {
        public List<Servicio> ObtenerTodos()
        {
            using (var conexion = ConexionBD.ObtenerConexion())
            {
                string sql = "SELECT IdServicio, NombreServicio, Descripcion FROM Servicio";
                return conexion.Query<Servicio>(sql).ToList();
            }
        }

        public Servicio ObtenerPorId(int idServicio)
        {
            using (var conexion = ConexionBD.ObtenerConexion())
            {
                string sql = "SELECT IdServicio, NombreServicio, Descripcion FROM Servicio WHERE IdServicio = @IdServicio";
                return conexion.QueryFirstOrDefault<Servicio>(sql, new { IdServicio = idServicio });
            }
        }
    }
}