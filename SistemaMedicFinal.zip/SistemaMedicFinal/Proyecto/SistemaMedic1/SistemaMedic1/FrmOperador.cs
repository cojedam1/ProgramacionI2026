﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace SistemaMedic
{
    public partial class FrmOperador : Form
    {
        private GestorTurno _gestor;
        private Operador _operador;
        private FrmSala _frmSala;
        private LectorVoz _lectorVoz;

        private Label lblTitulo, lblOperador, lblTurnoActual, lblContador;
        private Button btnLlamar, btnAbrirSala, btnHistorial;
        private ListBox lstCola;
        private System.Windows.Forms.Timer timerActualizar;

        public FrmOperador(GestorTurno gestor, Operador operador)
        {
            _gestor = gestor;
            _operador = operador;
            _frmSala = new FrmSala(gestor);
            _lectorVoz = new LectorVoz();
            InicializarComponentes();
            ActualizarCola();

            _gestor.TurnoLlamado += OnTurnoLlamado;
        }

        private void InicializarComponentes()
        {
            lblTitulo = new Label { Text = "SistemaMedic - Panel Operador", Font = new Font("Segoe UI", 14F, FontStyle.Bold), Location = new Point(20, 20), Size = new Size(460, 30), TextAlign = ContentAlignment.MiddleCenter };
            lblOperador = new Label { Text = $"Operador: {_operador.Nombre} | Ventanilla: {_operador.NumeroVentanilla}", Location = new Point(20, 60), Size = new Size(460, 23), TextAlign = ContentAlignment.MiddleCenter };
            lblTurnoActual = new Label { Text = "Turno actual: ---", Font = new Font("Segoe UI", 18F, FontStyle.Bold), Location = new Point(20, 95), Size = new Size(460, 40), TextAlign = ContentAlignment.MiddleCenter, ForeColor = Color.DarkBlue };
            lblContador = new Label { Text = "En espera: 0", Location = new Point(20, 145), Size = new Size(460, 23), TextAlign = ContentAlignment.MiddleCenter };

            lstCola = new ListBox { Location = new Point(20, 180), Size = new Size(460, 200) };

            btnLlamar = new Button { Text = "▶ Llamar Siguiente", Location = new Point(20, 395), Size = new Size(200, 45), BackColor = Color.SeaGreen, ForeColor = Color.White, Font = new Font("Segoe UI", 11F, FontStyle.Bold) };
            btnAbrirSala = new Button { Text = "Pantalla de Sala", Location = new Point(235, 395), Size = new Size(130, 45), BackColor = Color.SteelBlue, ForeColor = Color.White };
            btnHistorial = new Button { Text = "Historial", Location = new Point(375, 395), Size = new Size(105, 45) };

            btnLlamar.Click += btnLlamar_Click;
            btnAbrirSala.Click += btnAbrirSala_Click;
            btnHistorial.Click += btnHistorial_Click;

            // Timer para actualizar la cola automáticamente
            timerActualizar = new System.Windows.Forms.Timer { Interval = 1000 };
            timerActualizar.Tick += (s, e) => ActualizarCola();
            timerActualizar.Start();

            ClientSize = new Size(500, 460);
            Text = "SistemaMedic - Panel Operador";
            StartPosition = FormStartPosition.CenterScreen;

            Controls.AddRange(new Control[] { lblTitulo, lblOperador, lblTurnoActual, lblContador, lstCola, btnLlamar, btnAbrirSala, btnHistorial });
        }

        private void btnLlamar_Click(object sender, EventArgs e)
        {
            if (_gestor.CantidadEnEspera() == 0)
            {
                MessageBox.Show("No hay turnos en espera.", "Sin turnos", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            Turno turno = _gestor.LlamarSiguiente(_operador.Id);
            _lectorVoz.LlamarPaciente(turno, _operador.NumeroVentanilla);
            ActualizarCola();
        }

        private void OnTurnoLlamado(Turno turno)
        {
            if (InvokeRequired)
            {
                Invoke(new Action<Turno>(OnTurnoLlamado), turno);
                return;
            }

            string nombrePaciente = turno.Paciente != null ? turno.Paciente.Nombre : "";
            lblTurnoActual.Text = $"Turno #{turno.NumeroTurno:D3} - {nombrePaciente}";
            lblTurnoActual.ForeColor = turno.TipoTurno == "Preferencial" ? Color.DarkRed : Color.DarkBlue;
        }

        private void ActualizarCola()
        {
            lstCola.Items.Clear();
            lblContador.Text = $"En espera: {_gestor.CantidadEnEspera()}";

            var cola = new System.Collections.Generic.List<Turno>(_gestor.ObtenerCola());
            for (int i = 0; i < cola.Count; i++)
            {
                string nombrePaciente = cola[i].Paciente != null ? cola[i].Paciente.Nombre : "";
                string item = $"{i + 1}. Turno #{cola[i].NumeroTurno:D3} - {nombrePaciente} - {cola[i].NombreServicio}";
                lstCola.Items.Add(item);
            }
        }

        private void btnAbrirSala_Click(object sender, EventArgs e)
        {
            if (_frmSala == null || _frmSala.IsDisposed)
            {
                _frmSala = new FrmSala(_gestor);
            }

            _frmSala.Show();
            _frmSala.BringToFront();
        }

        private void btnHistorial_Click(object sender, EventArgs e)
        {
            var frmHistorial = new FrmHistorial();
            frmHistorial.Show();
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            _gestor.TurnoLlamado -= OnTurnoLlamado;
            timerActualizar.Stop();
            base.OnFormClosing(e);
        }
    }
}