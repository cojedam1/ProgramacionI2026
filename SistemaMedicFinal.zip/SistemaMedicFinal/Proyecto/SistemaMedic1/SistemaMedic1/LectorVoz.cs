﻿using System.Speech.Synthesis;

namespace SistemaMedic
{
    public class LectorVoz
    {
        private SpeechSynthesizer _sintetizador;

        public LectorVoz()
        {
            _sintetizador = new SpeechSynthesizer();

            // Intentar usar una voz en español si está disponible
            foreach (var voz in _sintetizador.GetInstalledVoices())
            {
                if (voz.VoiceInfo.Culture.Name.StartsWith("es"))
                {
                    _sintetizador.SelectVoice(voz.VoiceInfo.Name);
                    break;
                }
            }

            _sintetizador.Rate = 0;     // Velocidad: -10 (lento) a 10 (rápido)
            _sintetizador.Volume = 100; // Volumen: 0 a 100
        }

        public void LlamarPaciente(Turno turno, int numeroVentanilla)
        {
            string nombre = turno.Paciente != null ? turno.Paciente.Nombre : "";
            string tipo = turno.TipoTurno == "Preferencial" ? "preferencial" : "";

            string mensaje = $"{nombre}, turno {tipo} número {turno.NumeroTurno}, pase a ventanilla {numeroVentanilla}";

            // Hablar de forma asíncrona (no bloquea la pantalla)
            _sintetizador.SpeakAsync(mensaje);
        }
    }
}