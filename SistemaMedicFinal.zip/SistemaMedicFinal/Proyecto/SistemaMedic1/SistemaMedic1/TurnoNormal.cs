﻿using System;

namespace SistemaMedic
{
    public class TurnoNormal : Turno
    {
        public TurnoNormal(int numeroTurno, int idServicio, int idPaciente)
            : base(numeroTurno, idServicio, idPaciente)
        {
            TipoTurno = "Normal";
        }

        // Constructor vacío para Dapper
        public TurnoNormal() { }

        public override string MostrarTurno()
        {
            return $"TURNO NORMAL #{NumeroTurno:D3} - {NombreServicio}";
        }

        public override int ObtenerPrioridad()
        {
            return 2;
        }
    }
}