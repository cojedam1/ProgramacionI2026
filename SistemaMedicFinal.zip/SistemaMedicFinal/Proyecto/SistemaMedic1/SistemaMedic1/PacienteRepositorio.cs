﻿using Dapper;
using System.Collections.Generic;
using System.Linq;

namespace SistemaMedic
{
    public class PacienteRepositorio
    {
        public List<Paciente> ObtenerTodos()
        {
            using (var conexion = ConexionBD.ObtenerConexion())
            {
                string sql = "SELECT IdPaciente, Nombre, DPI, Telefono, FechaNacimiento, EsPreferencial FROM Paciente";
                return conexion.Query<Paciente>(sql).ToList();
            }
        }

        public Paciente ObtenerPorDPI(string dpi)
        {
            using (var conexion = ConexionBD.ObtenerConexion())
            {
                string sql = "SELECT IdPaciente, Nombre, DPI, Telefono, FechaNacimiento, EsPreferencial FROM Paciente WHERE DPI = @DPI";
                return conexion.QueryFirstOrDefault<Paciente>(sql, new { DPI = dpi });
            }
        }

        public int Insertar(Paciente paciente)
        {
            using (var conexion = ConexionBD.ObtenerConexion())
            {
                string sql = @"INSERT INTO Paciente (Nombre, DPI, Telefono, FechaNacimiento, EsPreferencial)
                               VALUES (@Nombre, @DPI, @Telefono, @FechaNacimiento, @EsPreferencial);
                               SELECT CAST(SCOPE_IDENTITY() AS INT)";
                return conexion.ExecuteScalar<int>(sql, paciente);
            }
        }

        public bool ExisteDPI(string dpi)
        {
            using (var conexion = ConexionBD.ObtenerConexion())
            {
                string sql = "SELECT COUNT(1) FROM Paciente WHERE DPI = @DPI";
                return conexion.ExecuteScalar<int>(sql, new { DPI = dpi }) > 0;
            }
        }
    }
}