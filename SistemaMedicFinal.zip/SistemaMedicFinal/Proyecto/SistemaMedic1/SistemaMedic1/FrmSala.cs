﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace SistemaMedic
{
    public partial class FrmSala : Form
    {
        private GestorTurno _gestor;
        private Label lblTitulo, lblTurno, lblServicio, lblTipo;
        private System.Windows.Forms.Timer timer;
        private System.Windows.Forms.Timer timerReinicio;
        private bool _visible = true;
        private int _segundosSinTurno = 0;

        public FrmSala(GestorTurno gestor)
        {
            _gestor = gestor;
            _gestor.TurnoLlamado += OnTurnoLlamado;
            InicializarComponentes();
        }

        private void InicializarComponentes()
        {
            lblTitulo = new Label { Text = "SistemaMedic", Font = new Font("Segoe UI", 20F, FontStyle.Bold), Location = new Point(0, 30), Size = new Size(600, 50), TextAlign = ContentAlignment.MiddleCenter, ForeColor = Color.DarkBlue };
            lblTurno = new Label { Text = "---", Font = new Font("Segoe UI", 72F, FontStyle.Bold), Location = new Point(0, 120), Size = new Size(600, 150), TextAlign = ContentAlignment.MiddleCenter, ForeColor = Color.DarkBlue };
            lblServicio = new Label { Text = "Esperando turno...", Font = new Font("Segoe UI", 18F), Location = new Point(0, 290), Size = new Size(600, 40), TextAlign = ContentAlignment.MiddleCenter };
            lblTipo = new Label { Text = "", Font = new Font("Segoe UI", 14F, FontStyle.Bold), Location = new Point(0, 340), Size = new Size(600, 35), TextAlign = ContentAlignment.MiddleCenter };

            timer = new System.Windows.Forms.Timer { Interval = 1000 };
            timer.Tick += new EventHandler(Timer_Tick);
            timer.Start();

            // Timer para reinicio automático
            timerReinicio = new System.Windows.Forms.Timer { Interval = 1000 };
            timerReinicio.Tick += TimerReinicio_Tick;
            timerReinicio.Start();

            ClientSize = new Size(600, 400);
            Text = "SistemaMedic - Pantalla de Sala";
            StartPosition = FormStartPosition.CenterScreen;
            BackColor = Color.White;

            Controls.AddRange(new Control[] { lblTitulo, lblTurno, lblServicio, lblTipo });
        }

        private void OnTurnoLlamado(Turno turno)
        {
            if (InvokeRequired)
            {
                Invoke(new Action<Turno>(OnTurnoLlamado), turno);
                return;
            }

            lblTurno.Text = $"#{turno.NumeroTurno:D3}";

            string nombrePaciente = turno.Paciente != null ? turno.Paciente.Nombre : "";
            lblServicio.Text = $"{nombrePaciente} - {turno.NombreServicio}";

            if (turno.TipoTurno == "Preferencial")
            {
                lblTipo.Text = "★ TURNO PREFERENCIAL ★";
                lblTipo.ForeColor = Color.DarkRed;
                lblTurno.ForeColor = Color.DarkRed;
            }
            else
            {
                lblTipo.Text = "TURNO NORMAL";
                lblTipo.ForeColor = Color.DarkBlue;
                lblTurno.ForeColor = Color.DarkBlue;
            }

            // Reiniciar contador cuando llega un nuevo turno
            _segundosSinTurno = 0;
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            _visible = !_visible;
            lblTurno.Visible = _visible;
        }

        private void TimerReinicio_Tick(object sender, EventArgs e)
        {
            // Si no hay turnos en espera y ya se mostró uno, contar segundos
            if (_gestor.CantidadEnEspera() == 0 && lblTurno.Text != "---")
            {
                _segundosSinTurno++;

                // Después de 20 segundos sin turnos, reiniciar la pantalla
                if (_segundosSinTurno >= 20)
                {
                    lblTurno.Text = "---";
                    lblTurno.ForeColor = Color.DarkBlue;
                    lblServicio.Text = "Esperando turno...";
                    lblTipo.Text = "";
                    _segundosSinTurno = 0;
                }
            }
            else
            {
                _segundosSinTurno = 0;
            }
        }
        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            _gestor.TurnoLlamado -= OnTurnoLlamado;
            timer.Stop();
            timerReinicio.Stop();
            base.OnFormClosing(e);
        }
    }
}