﻿using System.Windows.Forms;

namespace SistemaMedic
{
    public partial class FrmSala : Form
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent() { }
    }
}