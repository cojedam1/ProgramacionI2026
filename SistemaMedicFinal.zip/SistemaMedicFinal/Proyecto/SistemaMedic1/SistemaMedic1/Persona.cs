﻿using System;

namespace SistemaMedic
{
    public abstract class Persona
    {
        // Encapsulación - propiedades privadas con get/set
        public int Id { get; set; }
        public string Nombre { get; set; }
        public string DPI { get; set; }
        public string Telefono { get; set; }

        // Constructor
        public Persona(string nombre, string dpi, string telefono)
        {
            Nombre = nombre;
            DPI = dpi;
            Telefono = telefono;
        }

        // Constructor vacío para Dapper
        public Persona() { }

        // Método abstracto - obliga a las clases hijas a implementarlo
        public abstract string ObtenerInfo();

        public override string ToString()
        {
            return $"{Nombre} - DPI: {DPI}";
        }
    }
}