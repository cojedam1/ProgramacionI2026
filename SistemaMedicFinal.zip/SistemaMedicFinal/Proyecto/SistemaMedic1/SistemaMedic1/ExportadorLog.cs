﻿using System;
using System.Collections.Generic;
using System.IO;

namespace SistemaMedic
{
    public class ExportadorLog
    {
        public string ExportarHistorial(List<Turno> historial)
        {
            string fecha = DateTime.Now.ToString("yyyy-MM-dd");
            string nombreArchivo = $"Historial_{fecha}.txt";
            string ruta = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), nombreArchivo);

            using (StreamWriter sw = new StreamWriter(ruta, false))
            {
                sw.WriteLine("========================================");
                sw.WriteLine($"   SISTEMMEDIC - HISTORIAL DEL DÍA");
                sw.WriteLine($"   Fecha: {DateTime.Now:dd/MM/yyyy}");
                sw.WriteLine("========================================");
                sw.WriteLine();

                int totalAtendidos = 0;
                int totalPreferenciales = 0;

                // For loop para escribir cada turno
                for (int i = 0; i < historial.Count; i++)
                {
                    var t = historial[i];
                    sw.WriteLine($"Turno #{t.NumeroTurno:D3}");
                    sw.WriteLine($"  Servicio  : {t.NombreServicio}");
                    sw.WriteLine($"  Tipo      : {t.TipoTurno}");
                    sw.WriteLine($"  Registro  : {t.HoraRegistro:HH:mm}");
                    sw.WriteLine($"  Llamado   : {(t.HoraLlamado.HasValue ? t.HoraLlamado.Value.ToString("HH:mm") : "---")}");
                    sw.WriteLine($"  Estado    : {t.Estado}");
                    sw.WriteLine("----------------------------------------");

                    if (t.Estado == "Atendido") totalAtendidos++;
                    if (t.TipoTurno == "Preferencial") totalPreferenciales++;
                }

                sw.WriteLine();
                sw.WriteLine("========================================");
                sw.WriteLine($"  Total atendidos    : {totalAtendidos}");
                sw.WriteLine($"  Total preferenciales: {totalPreferenciales}");
                sw.WriteLine($"  Total en sistema   : {historial.Count}");
                sw.WriteLine("========================================");
            }

            return ruta;
        }
    }
}